import { Task, Aircraft, PriorityFactors } from '../types';

export class PriorityEngine {
  private weights = {
    timeToDelivery: 0.25,
    timeToPulse: 0.20,
    criticalPath: 0.30,
    resourceAvailability: 0.10,
    predecessorCompletion: 0.10,
    areaBlocking: 0.05
  };

  // Global priority calculation considering all aircraft in flow
  calculateGlobalPriorities(allTasks: Task[], allAircraft: Aircraft[]): Task[] {
    // First, calculate base priorities for each task
    const tasksWithBasePriority = allTasks.map(task => {
      const aircraft = allAircraft.find(ac => ac.id === task.aircraftId);
      if (!aircraft) return { ...task, globalPriority: 0 };
      
      const basePriority = this.calculatePriority(task, aircraft, allTasks);
      return { ...task, basePriority, globalPriority: basePriority };
    });

    // Apply global factors that affect cross-aircraft priorities
    const globalFactors = this.calculateGlobalFactors(tasksWithBasePriority, allAircraft);
    
    // Calculate final global priorities
    const tasksWithGlobalPriority = tasksWithBasePriority.map(task => {
      const aircraft = allAircraft.find(ac => ac.id === task.aircraftId);
      if (!aircraft) return task;
      
      const globalPriority = this.applyGlobalAdjustments(
        task.basePriority || task.priority,
        task,
        aircraft,
        globalFactors,
        allTasks,
        allAircraft
      );
      
      return { ...task, globalPriority, priority: globalPriority };
    });

    // Sort by global priority and return
    return tasksWithGlobalPriority.sort((a, b) => (b.globalPriority || 0) - (a.globalPriority || 0));
  }

  private calculateGlobalFactors(tasks: Task[], aircraft: Aircraft[]) {
    // Calculate resource contention across all aircraft
    const resourceContention = this.calculateResourceContention(tasks);
    
    // Calculate position-based flow priorities
    const positionFlowPriority = this.calculatePositionFlowPriority(aircraft);
    
    // Calculate cross-aircraft dependencies
    const crossAircraftDependencies = this.calculateCrossAircraftDependencies(tasks, aircraft);
    
    // Calculate system bottlenecks
    const systemBottlenecks = this.identifySystemBottlenecks(tasks, aircraft);
    
    return {
      resourceContention,
      positionFlowPriority,
      crossAircraftDependencies,
      systemBottlenecks
    };
  }

  private applyGlobalAdjustments(
    basePriority: number,
    task: Task,
    aircraft: Aircraft,
    globalFactors: any,
    allTasks: Task[],
    allAircraft: Aircraft[]
  ): number {
    let adjustedPriority = basePriority;
    
    // 1. Production Flow Optimization
    // Prioritize tasks that keep the overall flow moving
    const flowMultiplier = this.calculateFlowOptimizationMultiplier(task, aircraft, allAircraft);
    adjustedPriority *= flowMultiplier;
    
    // 2. Resource Contention Adjustment
    // Boost priority for tasks competing for scarce resources
    const resourceContentionBoost = globalFactors.resourceContention[task.id] || 0;
    adjustedPriority += resourceContentionBoost;
    
    // 3. System Bottleneck Priority
    // Higher priority for tasks in bottleneck areas
    if (globalFactors.systemBottlenecks.includes(this.getTaskArea(task))) {
      adjustedPriority *= 1.2;
    }
    
    // 4. Cross-Aircraft Dependency Impact
    // Boost tasks that unblock work on multiple aircraft
    const crossAircraftImpact = globalFactors.crossAircraftDependencies[task.id] || 0;
    adjustedPriority += crossAircraftImpact;
    
    // 5. Position Flow Priority
    // Prioritize based on position urgency and flow requirements
    const positionMultiplier = globalFactors.positionFlowPriority[aircraft.currentPosition] || 1.0;
    adjustedPriority *= positionMultiplier;
    
    // 6. Overall System Health Impact
    // Consider how this task affects overall production metrics
    const systemHealthImpact = this.calculateSystemHealthImpact(task, aircraft, allTasks, allAircraft);
    adjustedPriority += systemHealthImpact;
    
    return Math.min(100, Math.max(0, Math.round(adjustedPriority)));
  }

  private calculateFlowOptimizationMultiplier(task: Task, aircraft: Aircraft, allAircraft: Aircraft[]): number {
    // Base multiplier
    let multiplier = 1.0;
    
    // Aircraft closest to pulse deadline get higher priority
    const now = new Date();
    const daysToPulse = Math.max(0, (aircraft.expectedPulseDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysToPulse <= 1) {
      multiplier *= 1.5; // Critical - must pulse soon
    } else if (daysToPulse <= 2) {
      multiplier *= 1.3; // High priority
    } else if (daysToPulse <= 3) {
      multiplier *= 1.1; // Elevated priority
    }
    
    // Aircraft in earlier positions get priority to maintain flow
    const positionPriority = {
      0: 1.2, // Highest - must move quickly
      1: 1.15,
      2: 1.1,
      3: 1.05,
      '-1': 1.0 // FGI - normal priority
    };
    
    multiplier *= positionPriority[aircraft.currentPosition] || 1.0;
    
    return multiplier;
  }

  private calculateResourceContention(tasks: Task[]): { [taskId: string]: number } {
    const contention: { [taskId: string]: number } = {};
    
    // Group tasks by resource requirements
    const resourceGroups: { [key: string]: Task[] } = {};
    
    tasks.forEach(task => {
      if (task.status === 'not_started' || task.status === 'in_progress') {
        const resourceKey = `${task.resourceCount}-${this.getTaskArea(task)}`;
        if (!resourceGroups[resourceKey]) {
          resourceGroups[resourceKey] = [];
        }
        resourceGroups[resourceKey].push(task);
      }
    });
    
    // Calculate contention boost for each task
    Object.values(resourceGroups).forEach(group => {
      if (group.length > 3) { // High contention
        group.forEach(task => {
          contention[task.id] = 15; // Significant boost
        });
      } else if (group.length > 1) { // Moderate contention
        group.forEach(task => {
          contention[task.id] = 8; // Moderate boost
        });
      }
    });
    
    return contention;
  }

  private calculatePositionFlowPriority(aircraft: Aircraft[]): { [position: number]: number } {
    const positionCounts = aircraft.reduce((acc, ac) => {
      acc[ac.currentPosition] = (acc[ac.currentPosition] || 0) + 1;
      return acc;
    }, {} as { [position: number]: number });
    
    // Higher multiplier for positions with fewer aircraft (less congested)
    const priorities: { [position: number]: number } = {};
    
    [0, 1, 2, 3, -1].forEach(position => {
      const count = positionCounts[position] || 0;
      if (count === 0) {
        priorities[position] = 1.0; // No aircraft in position
      } else if (count === 1) {
        priorities[position] = 1.1; // Single aircraft - prioritize to maintain flow
      } else {
        priorities[position] = 1.0 / Math.sqrt(count); // More aircraft = lower individual priority
      }
    });
    
    return priorities;
  }

  private calculateCrossAircraftDependencies(tasks: Task[], aircraft: Aircraft[]): { [taskId: string]: number } {
    // This would analyze if completing a task unblocks work on other aircraft
    // For now, return empty object - would need more complex dependency modeling
    return {};
  }

  private identifySystemBottlenecks(tasks: Task[], aircraft: Aircraft[]): string[] {
    // Identify areas with high task density and long durations
    const areaWorkload: { [area: string]: { count: number; totalDuration: number } } = {};
    
    tasks.forEach(task => {
      if (task.status === 'not_started' || task.status === 'in_progress') {
        const area = this.getTaskArea(task);
        if (!areaWorkload[area]) {
          areaWorkload[area] = { count: 0, totalDuration: 0 };
        }
        areaWorkload[area].count++;
        areaWorkload[area].totalDuration += task.duration;
      }
    });
    
    // Return areas with high workload density
    return Object.entries(areaWorkload)
      .filter(([_, workload]) => workload.count > 5 && workload.totalDuration > 800)
      .map(([area, _]) => area);
  }

  private calculateSystemHealthImpact(task: Task, aircraft: Aircraft, allTasks: Task[], allAircraft: Aircraft[]): number {
    let impact = 0;
    
    // Tasks on critical path have higher system impact
    if (task.criticalPath) {
      impact += 10;
    }
    
    // Area-exclusive tasks that block others have high impact
    if (task.areaExclusive) {
      impact += 8;
    }
    
    // Tasks with many dependencies have higher impact
    const dependentTasks = allTasks.filter(t => 
      t.relationships.some(rel => rel.taskId === task.id && rel.type === 'predecessor')
    );
    impact += Math.min(15, dependentTasks.length * 3);
    
    return impact;
  }

  private getTaskArea(task: Task): string {
    // Simplified area classification based on task name
    const name = task.name.toLowerCase();
    if (name.includes('wing')) return 'Wing Assembly';
    if (name.includes('hydraulic')) return 'Hydraulic Systems';
    if (name.includes('engine')) return 'Engine Systems';
    if (name.includes('cabin') || name.includes('interior')) return 'Interior Systems';
    if (name.includes('fuselage')) return 'Fuselage Assembly';
    return 'General Assembly';
  }
  calculatePriority(task: Task, aircraft: Aircraft, allTasks: Task[]): number {
    const factors = this.calculateFactors(task, aircraft, allTasks);
    
    let priority = 0;
    priority += factors.timeToDelivery * this.weights.timeToDelivery;
    priority += factors.timeToPulse * this.weights.timeToPulse;
    priority += factors.criticalPath * this.weights.criticalPath;
    priority += factors.resourceAvailability * this.weights.resourceAvailability;
    priority += factors.predecessorCompletion * this.weights.predecessorCompletion;
    priority += factors.areaBlocking * this.weights.areaBlocking;

    return Math.round(priority * 100); // Scale to 0-100
  }

  private calculateFactors(task: Task, aircraft: Aircraft, allTasks: Task[]): PriorityFactors {
    const now = new Date();
    const timeToDelivery = Math.max(0, aircraft.deliveryDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24);
    const timeToPulse = Math.max(0, aircraft.expectedPulseDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24);

    return {
      timeToDelivery: this.normalizeTimeUrgency(timeToDelivery),
      timeToPulse: this.normalizeTimeUrgency(timeToPulse),
      criticalPath: task.criticalPath ? 1.0 : 0.3,
      resourceAvailability: this.calculateResourceAvailability(task),
      predecessorCompletion: this.calculatePredecessorCompletion(task, allTasks),
      areaBlocking: task.areaExclusive ? 1.0 : 0.0,
      earnedValueImpact: this.calculateEarnedValueImpact(task, aircraft)
    };
  }

  private normalizeTimeUrgency(daysRemaining: number): number {
    if (daysRemaining <= 0) return 1.0;
    if (daysRemaining >= 30) return 0.1;
    return Math.max(0.1, 1.0 - (daysRemaining / 30));
  }

  private calculateResourceAvailability(task: Task): number {
    // Simplified - in real system would check actual resource availability
    const baseAvailability = 0.7;
    const resourcePenalty = Math.min(0.3, (task.resourceCount - 1) * 0.1);
    return Math.max(0.1, baseAvailability - resourcePenalty);
  }

  private calculatePredecessorCompletion(task: Task, allTasks: Task[]): number {
    const predecessors = task.relationships
      .filter(rel => rel.type === 'predecessor')
      .map(rel => allTasks.find(t => t.id === rel.taskId))
      .filter(Boolean);

    if (predecessors.length === 0) return 1.0;

    const completedPredecessors = predecessors.filter(t => t?.status === 'completed').length;
    return completedPredecessors / predecessors.length;
  }

  private calculateEarnedValueImpact(task: Task, aircraft: Aircraft): number {
    // Calculate how much this task impacts the overall earned value
    const taskValue = task.duration / 60; // Convert to hours for value calculation
    const totalValue = aircraft.plannedValue;
    return Math.min(1.0, taskValue / totalValue * 10);
  }

  calculateGamePoints(task: Task, completionTime: number, quality: number = 1.0): number {
    const basePoints = task.priority;
    const efficiencyBonus = Math.max(0, (task.duration - completionTime) / task.duration * 0.5);
    const qualityMultiplier = quality;
    
    return Math.round(basePoints * (1 + efficiencyBonus) * qualityMultiplier);
  }
}