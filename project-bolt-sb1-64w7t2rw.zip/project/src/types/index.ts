export interface Task {
  id: string;
  name: string;
  description: string;
  duration: number; // in minutes
  resourceCount: number;
  position?: number; // 0-3 or null for FGI
  aircraftId: string;
  status: 'not_started' | 'in_progress' | 'completed' | 'blocked';
  priority: number;
  globalPriority?: number;
  basePriority?: number;
  scheduledStart?: Date;
  actualStart?: Date;
  actualEnd?: Date;
  relationships: TaskRelationship[];
  areaExclusive: boolean; // blocks all other work in area
  criticalPath: boolean;
}

export interface TaskRelationship {
  type: 'predecessor' | 'successor' | 'concurrent' | 'mutually_exclusive';
  taskId: string;
  lag?: number; // delay in minutes
}

export interface Aircraft {
  id: string;
  serialNumber: string;
  currentPosition: number; // 0-3 or -1 for FGI
  entryDate: Date;
  expectedPulseDate: Date;
  deliveryDate: Date;
  completedTasks: number;
  totalTasks: number;
  earnedValue: number;
  plannedValue: number;
  actualCost: number;
}

export interface Worker {
  id: string;
  name: string;
  skills: string[];
  currentTask?: string;
  pointsEarned: number;
  level: number;
  achievements: Achievement[];
  efficiency: number; // multiplier for task completion
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  pointsRequired: number;
  unlocked: boolean;
  unlockedAt?: Date;
}

export interface PriorityFactors {
  timeToDelivery: number;
  timeToPulse: number;
  criticalPath: number;
  resourceAvailability: number;
  predecessorCompletion: number;
  areaBlocking: number;
  earnedValueImpact: number;
}

export interface ProductionMetrics {
  onTimeDelivery: number;
  schedulePerformanceIndex: number;
  costPerformanceIndex: number;
  tasksCompletedToday: number;
  averageTaskDuration: number;
  bottleneckAreas: string[];
  workerUtilization: number;
}