import { Task, Aircraft, Worker, Achievement } from '../types';

export const mockAircraft: Aircraft[] = [
  {
    id: 'ac-001',
    serialNumber: 'B787-001',
    currentPosition: 1,
    entryDate: new Date('2024-01-05'),
    expectedPulseDate: new Date('2024-01-17'),
    deliveryDate: new Date('2024-03-15'),
    completedTasks: 1250,
    totalTasks: 6000,
    earnedValue: 2850000,
    plannedValue: 3200000,
    actualCost: 3100000
  },
  {
    id: 'ac-002',
    serialNumber: 'B787-002',
    currentPosition: 2,
    entryDate: new Date('2024-01-01'),
    expectedPulseDate: new Date('2024-01-21'),
    deliveryDate: new Date('2024-03-11'),
    completedTasks: 2100,
    totalTasks: 6000,
    earnedValue: 4200000,
    plannedValue: 4000000,
    actualCost: 4150000
  },
  {
    id: 'ac-003',
    serialNumber: 'B787-003',
    currentPosition: -1, // FGI
    entryDate: new Date('2023-12-08'),
    expectedPulseDate: new Date('2024-01-23'),
    deliveryDate: new Date('2024-02-16'),
    completedTasks: 5650,
    totalTasks: 6000,
    earnedValue: 11300000,
    plannedValue: 12000000,
    actualCost: 11800000
  }
];

export const mockTasks: Task[] = [
  {
    id: 'task-001',
    name: 'Wing Assembly Installation',
    description: 'Install and secure wing assembly components',
    duration: 240,
    resourceCount: 4,
    position: 1,
    aircraftId: 'ac-001',
    status: 'in_progress',
    priority: 85,
    relationships: [
      { type: 'predecessor', taskId: 'task-005' },
      { type: 'successor', taskId: 'task-002' }
    ],
    areaExclusive: true,
    criticalPath: true
  },
  {
    id: 'task-002',
    name: 'Hydraulic System Testing',
    description: 'Test and validate hydraulic system pressure',
    duration: 90,
    resourceCount: 2,
    position: 1,
    aircraftId: 'ac-001',
    status: 'not_started',
    priority: 72,
    relationships: [
      { type: 'predecessor', taskId: 'task-001' }
    ],
    areaExclusive: false,
    criticalPath: true
  },
  {
    id: 'task-003',
    name: 'Cabin Interior Fitting',
    description: 'Install cabin interior components and seating',
    duration: 180,
    resourceCount: 6,
    position: 2,
    aircraftId: 'ac-002',
    status: 'in_progress',
    priority: 68,
    relationships: [],
    areaExclusive: false,
    criticalPath: false
  },
  {
    id: 'task-004',
    name: 'Engine Mount Inspection',
    description: 'Final inspection of engine mount systems',
    duration: 120,
    resourceCount: 1,
    position: -1,
    aircraftId: 'ac-003',
    status: 'not_started',
    priority: 95,
    relationships: [],
    areaExclusive: false,
    criticalPath: true
  },
  {
    id: 'task-005',
    name: 'Fuselage Preparation',
    description: 'Prepare fuselage for wing assembly',
    duration: 150,
    resourceCount: 3,
    position: 1,
    aircraftId: 'ac-001',
    status: 'completed',
    priority: 0,
    relationships: [
      { type: 'successor', taskId: 'task-001' }
    ],
    areaExclusive: false,
    criticalPath: true
  }
];

export const mockWorkers: Worker[] = [
  {
    id: 'worker-001',
    name: 'Sarah Chen',
    skills: ['Wing Assembly', 'Hydraulics', 'Quality Control'],
    currentTask: 'task-001',
    pointsEarned: 15420,
    level: 12,
    achievements: [
      {
        id: 'ach-001',
        name: 'Speed Demon',
        description: 'Complete 10 tasks ahead of schedule',
        icon: 'zap',
        pointsRequired: 1000,
        unlocked: true,
        unlockedAt: new Date('2024-01-15')
      }
    ],
    efficiency: 1.15
  },
  {
    id: 'worker-002',
    name: 'Marcus Rodriguez',
    skills: ['Engine Systems', 'Inspection', 'Testing'],
    currentTask: 'task-004',
    pointsEarned: 18750,
    level: 15,
    achievements: [
      {
        id: 'ach-002',
        name: 'Quality Master',
        description: 'Complete 50 tasks with perfect quality',
        icon: 'award',
        pointsRequired: 5000,
        unlocked: true,
        unlockedAt: new Date('2024-01-10')
      }
    ],
    efficiency: 1.25
  },
  {
    id: 'worker-003',
    name: 'Jennifer Park',
    skills: ['Interior Systems', 'Electrical', 'Cabin Assembly'],
    currentTask: 'task-003',
    pointsEarned: 12980,
    level: 10,
    achievements: [],
    efficiency: 1.08
  }
];

export const mockAchievements: Achievement[] = [
  {
    id: 'ach-001',
    name: 'Speed Demon',
    description: 'Complete 10 tasks ahead of schedule',
    icon: 'zap',
    pointsRequired: 1000,
    unlocked: false
  },
  {
    id: 'ach-002',
    name: 'Quality Master',
    description: 'Complete 50 tasks with perfect quality',
    icon: 'award',
    pointsRequired: 5000,
    unlocked: false
  },
  {
    id: 'ach-003',
    name: 'Team Player',
    description: 'Complete 25 multi-person tasks',
    icon: 'users',
    pointsRequired: 2500,
    unlocked: false
  },
  {
    id: 'ach-004',
    name: 'Critical Path Hero',
    description: 'Complete 15 critical path tasks on time',
    icon: 'target',
    pointsRequired: 3000,
    unlocked: false
  },
  {
    id: 'ach-005',
    name: 'Problem Solver',
    description: 'Resolve 10 blocked tasks',
    icon: 'wrench',
    pointsRequired: 1500,
    unlocked: false
  }
];