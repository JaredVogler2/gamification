import React, { useState, useEffect } from 'react';
import { Navigation } from './components/Navigation';
import { TaskPriorityList } from './components/TaskPriorityList';
import { ProductionFlowChart } from './components/ProductionFlowChart';
import { GamificationPanel } from './components/GamificationPanel';
import { VPDashboard } from './components/VPDashboard';
import { EVMGuide } from './components/EVMGuide';
import { EarnedValueChart } from './components/EarnedValueChart';
import { PriorityEngine } from './utils/priorityEngine';
import { mockTasks, mockAircraft, mockWorkers, mockAchievements } from './data/mockData';
import { Task, Aircraft, Worker, Achievement, ProductionMetrics } from './types';

function App() {
  const [activeTab, setActiveTab] = useState('tasks');
  const [tasks, setTasks] = useState<Task[]>(mockTasks);
  const [aircraft, setAircraft] = useState<Aircraft[]>(mockAircraft);
  const [workers, setWorkers] = useState<Worker[]>(mockWorkers);
  const [achievements, setAchievements] = useState<Achievement[]>(mockAchievements);
  const [priorityEngine] = useState(new PriorityEngine());

  const productionMetrics: ProductionMetrics = {
    onTimeDelivery: 0.87,
    schedulePerformanceIndex: 0.94,
    costPerformanceIndex: 0.98,
    tasksCompletedToday: 142,
    averageTaskDuration: 156,
    bottleneckAreas: ['Wing Assembly Station', 'Hydraulic Testing Bay', 'Interior Fitting Area'],
    workerUtilization: 0.84
  };

  // Recalculate priorities when data changes
  useEffect(() => {
    const updatedTasks = tasks.map(task => {
      const taskAircraft = aircraft.find(ac => ac.id === task.aircraftId);
      if (taskAircraft && task.status !== 'completed') {
        const newPriority = priorityEngine.calculatePriority(task, taskAircraft, tasks);
        return { ...task, priority: newPriority };
      }
      return task;
    });
    
    if (JSON.stringify(updatedTasks) !== JSON.stringify(tasks)) {
      setTasks(updatedTasks);
    }
  }, [aircraft, priorityEngine]);

  const renderContent = () => {
    switch (activeTab) {
      case 'tasks':
        return (
          <div className="space-y-6">
            <TaskPriorityList tasks={tasks} aircraft={aircraft} priorityEngine={priorityEngine} />
          </div>
        );
      case 'production':
        return (
          <div className="space-y-6">
            <ProductionFlowChart aircraft={aircraft} />
            <EarnedValueChart aircraft={aircraft} />
          </div>
        );
      case 'gamification':
        return (
          <div className="space-y-6">
            <GamificationPanel workers={workers} achievements={achievements} />
          </div>
        );
      case 'dashboard':
        return (
          <div className="space-y-6">
            <VPDashboard aircraft={aircraft} metrics={productionMetrics} />
          </div>
        );
      case 'evm-guide':
        return (
          <div className="space-y-6">
            <EVMGuide />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
      
      <main className="max-w-7xl mx-auto px-4 py-8">
        {renderContent()}
      </main>
    </div>
  );
}

export default App;