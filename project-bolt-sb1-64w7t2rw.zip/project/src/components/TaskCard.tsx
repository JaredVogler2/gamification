import React from 'react';
import { Task, Aircraft } from '../types';
import { Clock, Users, AlertTriangle, Target, Lock } from 'lucide-react';

interface TaskCardProps {
  task: Task;
  aircraft: Aircraft;
  onClick?: () => void;
}

export const TaskCard: React.FC<TaskCardProps> = ({ task, aircraft, onClick }) => {
  const getPriorityColor = (priority: number) => {
    if (priority >= 90) return 'border-red-500 bg-red-50';
    if (priority >= 75) return 'border-orange-500 bg-orange-50';
    if (priority >= 60) return 'border-yellow-500 bg-yellow-50';
    if (priority >= 40) return 'border-blue-500 bg-blue-50';
    return 'border-gray-500 bg-gray-50';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-600 bg-green-100';
      case 'in_progress': return 'text-blue-600 bg-blue-100';
      case 'blocked': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
  };

  return (
    <div 
      className={`p-4 rounded-lg border-2 cursor-pointer transition-all duration-200 hover:shadow-md ${getPriorityColor(task.priority)}`}
      onClick={onClick}
    >
      <div className="flex justify-between items-start mb-2">
        <h3 className="font-semibold text-gray-900 text-sm">{task.name}</h3>
        <div className="flex items-center space-x-2">
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(task.status)}`}>
            {task.status.replace('_', ' ').toUpperCase()}
          </span>
          <div className="bg-navy-600 text-white px-2 py-1 rounded text-xs font-bold">
            {task.priority}
          </div>
        </div>
      </div>
      
      <p className="text-gray-600 text-xs mb-3 line-clamp-2">{task.description}</p>
      
      <div className="flex items-center justify-between text-xs text-gray-500">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-1">
            <Clock className="w-3 h-3" />
            <span>{formatDuration(task.duration)}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Users className="w-3 h-3" />
            <span>{task.resourceCount}</span>
          </div>
        </div>
        
        <div className="flex items-center space-x-1">
          {task.criticalPath && <Target className="w-3 h-3 text-red-500" />}
          {task.areaExclusive && <Lock className="w-3 h-3 text-orange-500" />}
          {task.status === 'blocked' && <AlertTriangle className="w-3 h-3 text-red-500" />}
        </div>
      </div>
      
      <div className="mt-2">
        <div className="text-xs text-gray-500 mb-1">Aircraft: {aircraft.serialNumber} (Pos: {aircraft.currentPosition === -1 ? 'FGI' : aircraft.currentPosition})</div>
      </div>
    </div>
  );
};