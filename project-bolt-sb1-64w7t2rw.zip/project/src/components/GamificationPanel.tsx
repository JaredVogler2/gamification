import React from 'react';
import { Worker, Achievement } from '../types';
import { Trophy, Star, Target, Users, Zap, Award, Wrench } from 'lucide-react';

interface GamificationPanelProps {
  workers: Worker[];
  achievements: Achievement[];
}

export const GamificationPanel: React.FC<GamificationPanelProps> = ({ workers, achievements }) => {
  const topWorkers = [...workers].sort((a, b) => b.pointsEarned - a.pointsEarned).slice(0, 5);
  
  const getAchievementIcon = (iconName: string) => {
    switch (iconName) {
      case 'zap': return Zap;
      case 'award': return Award;
      case 'users': return Users;
      case 'target': return Target;
      case 'wrench': return Wrench;
      default: return Star;
    }
  };

  const getLevelColor = (level: number) => {
    if (level >= 15) return 'from-purple-500 to-pink-500';
    if (level >= 10) return 'from-blue-500 to-cyan-500';
    if (level >= 5) return 'from-green-500 to-emerald-500';
    return 'from-gray-500 to-gray-600';
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Leaderboard */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center space-x-2 mb-6">
          <Trophy className="w-6 h-6 text-yellow-500" />
          <h2 className="text-xl font-bold text-gray-900">Leaderboard</h2>
        </div>
        
        <div className="space-y-3">
          {topWorkers.map((worker, index) => (
            <div key={worker.id} className="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg">
              <div className="flex-shrink-0">
                <div className={`w-8 h-8 rounded-full bg-gradient-to-r ${getLevelColor(worker.level)} flex items-center justify-center text-white font-bold text-sm`}>
                  {index + 1}
                </div>
              </div>
              
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <span className="font-medium text-gray-900">{worker.name}</span>
                  <span className="text-navy-600 font-bold">{worker.pointsEarned.toLocaleString()}</span>
                </div>
                <div className="flex items-center space-x-4 text-xs text-gray-500">
                  <span>Level {worker.level}</span>
                  <span>Efficiency: {(worker.efficiency * 100).toFixed(0)}%</span>
                  <span>{worker.achievements.length} achievements</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Achievements */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center space-x-2 mb-6">
          <Award className="w-6 h-6 text-purple-500" />
          <h2 className="text-xl font-bold text-gray-900">Achievements</h2>
        </div>
        
        <div className="grid grid-cols-2 gap-3">
          {achievements.map(achievement => {
            const IconComponent = getAchievementIcon(achievement.icon);
            const isUnlocked = achievement.unlocked;
            
            return (
              <div 
                key={achievement.id} 
                className={`p-3 rounded-lg border-2 transition-all duration-200 ${
                  isUnlocked 
                    ? 'border-yellow-300 bg-yellow-50 shadow-sm' 
                    : 'border-gray-200 bg-gray-50 opacity-60'
                }`}
              >
                <div className="flex items-center space-x-2 mb-2">
                  <IconComponent className={`w-5 h-5 ${isUnlocked ? 'text-yellow-600' : 'text-gray-400'}`} />
                  <span className={`font-medium text-sm ${isUnlocked ? 'text-gray-900' : 'text-gray-500'}`}>
                    {achievement.name}
                  </span>
                </div>
                <p className="text-xs text-gray-600 mb-2">{achievement.description}</p>
                <div className="text-xs font-medium text-purple-600">
                  {achievement.pointsRequired.toLocaleString()} pts
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};