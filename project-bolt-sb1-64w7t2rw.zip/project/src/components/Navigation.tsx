import React from 'react';
import { Plane, Users, Trophy, BarChart3, Settings } from 'lucide-react';

interface NavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activeTab, onTabChange }) => {
  const tabs = [
    { id: 'tasks', label: 'Task Priority', icon: Plane },
    { id: 'production', label: 'Production Flow', icon: BarChart3 },
    { id: 'gamification', label: 'Worker Game', icon: Trophy },
    { id: 'dashboard', label: 'VP Dashboard', icon: Users },
    { id: 'evm-guide', label: 'EVM Guide', icon: Settings },
  ];

  return (
    <nav className="bg-navy-800 shadow-lg">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2 py-4">
            <Plane className="w-8 h-8 text-gold-400" />
            <span className="text-xl font-bold text-white">AeroFlow Priority</span>
          </div>
          
          <div className="flex space-x-1">
            {tabs.map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              
              return (
                <button
                  key={tab.id}
                  onClick={() => onTabChange(tab.id)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                    isActive 
                      ? 'bg-navy-600 text-white shadow-md' 
                      : 'text-gray-300 hover:text-white hover:bg-navy-700'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="hidden sm:inline">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </nav>
  );
};