import React from 'react';
import { Aircraft } from '../types';
import { Plane, Clock, TrendingUp, AlertCircle } from 'lucide-react';

interface ProductionFlowChartProps {
  aircraft: Aircraft[];
}

export const ProductionFlowChart: React.FC<ProductionFlowChartProps> = ({ aircraft }) => {
  const positions = [0, 1, 2, 3, -1]; // -1 represents FGI
  const positionNames = ['Position 0', 'Position 1', 'Position 2', 'Position 3', 'FGI'];

  const getPositionColor = (position: number) => {
    switch (position) {
      case 0: return 'bg-blue-100 border-blue-300';
      case 1: return 'bg-green-100 border-green-300';
      case 2: return 'bg-yellow-100 border-yellow-300';
      case 3: return 'bg-orange-100 border-orange-300';
      case -1: return 'bg-purple-100 border-purple-300';
      default: return 'bg-gray-100 border-gray-300';
    }
  };

  const getScheduleStatus = (aircraft: Aircraft) => {
    const now = new Date();
    const daysUntilPulse = Math.ceil((aircraft.expectedPulseDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysUntilPulse < 0) return { status: 'overdue', color: 'text-red-600', icon: AlertCircle };
    if (daysUntilPulse <= 1) return { status: 'urgent', color: 'text-orange-600', icon: Clock };
    return { status: 'on-track', color: 'text-green-600', icon: TrendingUp };
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-xl font-bold text-gray-900 mb-6">Production Flow</h2>
      
      <div className="grid grid-cols-5 gap-4">
        {positions.map((position, index) => {
          const aircraftInPosition = aircraft.filter(ac => ac.currentPosition === position);
          
          return (
            <div key={position} className="text-center">
              <h3 className="font-semibold text-gray-700 mb-3">{positionNames[index]}</h3>
              <div className={`min-h-32 p-3 rounded-lg border-2 ${getPositionColor(position)}`}>
                {aircraftInPosition.map(ac => {
                  const scheduleStatus = getScheduleStatus(ac);
                  const StatusIcon = scheduleStatus.icon;
                  
                  return (
                    <div key={ac.id} className="mb-3 last:mb-0">
                      <div className="bg-white rounded p-3 shadow-sm">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            <Plane className="w-4 h-4 text-navy-600" />
                            <span className="font-medium text-sm">{ac.serialNumber}</span>
                          </div>
                          <StatusIcon className={`w-4 h-4 ${scheduleStatus.color}`} />
                        </div>
                        
                        <div className="text-xs text-gray-600 space-y-1">
                          <div>Progress: {Math.round((ac.completedTasks / ac.totalTasks) * 100)}%</div>
                          <div>SPI: {(ac.earnedValue / ac.plannedValue).toFixed(2)}</div>
                          <div>CPI: {(ac.earnedValue / ac.actualCost).toFixed(2)}</div>
                        </div>
                        
                        <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                          <div 
                            className="bg-navy-600 h-2 rounded-full transition-all duration-300"
                            style={{ width: `${(ac.completedTasks / ac.totalTasks) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  );
                })}
                
                {aircraftInPosition.length === 0 && (
                  <div className="text-gray-400 text-sm italic">Empty</div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};