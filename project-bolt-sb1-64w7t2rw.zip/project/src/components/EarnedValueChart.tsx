import React from 'react';
import { Aircraft } from '../types';
import { TrendingUp, DollarSign, Target } from 'lucide-react';

interface EarnedValueChartProps {
  aircraft: Aircraft[];
}

export const EarnedValueChart: React.FC<EarnedValueChartProps> = ({ aircraft }) => {
  const totalEV = aircraft.reduce((sum, ac) => sum + ac.earnedValue, 0);
  const totalPV = aircraft.reduce((sum, ac) => sum + ac.plannedValue, 0);
  const totalAC = aircraft.reduce((sum, ac) => sum + ac.actualCost, 0);

  const spi = totalEV / totalPV;
  const cpi = totalEV / totalAC;
  const variance = totalEV - totalPV;

  const getPerformanceColor = (value: number, threshold: number = 1.0) => {
    if (value >= threshold) return 'text-green-600';
    if (value >= threshold * 0.9) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center space-x-2 mb-6">
        <TrendingUp className="w-6 h-6 text-blue-500" />
        <h2 className="text-xl font-bold text-gray-900">Earned Value Management</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div className="text-center p-4 bg-blue-50 rounded-lg">
          <DollarSign className="w-8 h-8 text-blue-600 mx-auto mb-2" />
          <div className="text-2xl font-bold text-blue-600">${(totalEV / 1000000).toFixed(1)}M</div>
          <div className="text-sm text-gray-600">Earned Value</div>
        </div>
        
        <div className="text-center p-4 bg-green-50 rounded-lg">
          <Target className="w-8 h-8 text-green-600 mx-auto mb-2" />
          <div className="text-2xl font-bold text-green-600">${(totalPV / 1000000).toFixed(1)}M</div>
          <div className="text-sm text-gray-600">Planned Value</div>
        </div>
        
        <div className="text-center p-4 bg-red-50 rounded-lg">
          <TrendingUp className="w-8 h-8 text-red-600 mx-auto mb-2" />
          <div className="text-2xl font-bold text-red-600">${(totalAC / 1000000).toFixed(1)}M</div>
          <div className="text-sm text-gray-600">Actual Cost</div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-4 border rounded-lg">
          <h3 className="font-semibold text-gray-900 mb-3">Performance Indices</h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Schedule Performance Index (SPI)</span>
              <span className={`font-bold text-lg ${getPerformanceColor(spi)}`}>
                {spi.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Cost Performance Index (CPI)</span>
              <span className={`font-bold text-lg ${getPerformanceColor(cpi)}`}>
                {cpi.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Schedule Variance</span>
              <span className={`font-bold text-lg ${variance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                ${(variance / 1000000).toFixed(1)}M
              </span>
            </div>
          </div>
        </div>

        <div className="p-4 border rounded-lg">
          <h3 className="font-semibold text-gray-900 mb-3">Performance Indicators</h3>
          <div className="space-y-3">
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm text-gray-600">Schedule Health</span>
                <span className="text-sm font-medium">{Math.round(spi * 100)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className={`h-2 rounded-full transition-all duration-500 ${
                    spi >= 1.0 ? 'bg-green-500' : spi >= 0.9 ? 'bg-yellow-500' : 'bg-red-500'
                  }`}
                  style={{ width: `${Math.min(100, spi * 100)}%` }}
                ></div>
              </div>
            </div>
            
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm text-gray-600">Cost Health</span>
                <span className="text-sm font-medium">{Math.round(cpi * 100)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className={`h-2 rounded-full transition-all duration-500 ${
                    cpi >= 1.0 ? 'bg-green-500' : cpi >= 0.9 ? 'bg-yellow-500' : 'bg-red-500'
                  }`}
                  style={{ width: `${Math.min(100, cpi * 100)}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};