import React, { useState } from 'react';
import { Task, Aircraft } from '../types';
import { TaskCard } from './TaskCard';
import { Search, Filter, SortAsc } from 'lucide-react';

interface TaskPriorityListProps {
  tasks: Task[];
  aircraft: Aircraft[];
  priorityEngine: any;
}

export const TaskPriorityList: React.FC<TaskPriorityListProps> = ({ tasks, aircraft, priorityEngine }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortBy, setSortBy] = useState('global_priority');
  const [showGlobalPriority, setShowGlobalPriority] = useState(true);

  // Calculate global priorities
  const globalTasks = React.useMemo(() => {
    return priorityEngine.calculateGlobalPriorities(tasks, aircraft);
  }, [tasks, aircraft, priorityEngine]);

  const getAircraftForTask = (taskAircraftId: string) => {
    return aircraft.find(ac => ac.id === taskAircraftId);
  };

  const filteredTasks = (showGlobalPriority ? globalTasks : tasks)
    .filter(task => {
      const matchesSearch = task.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           task.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = statusFilter === 'all' || task.status === statusFilter;
      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'global_priority':
          return (b.globalPriority || b.priority) - (a.globalPriority || a.priority);
        case 'priority':
          return b.priority - a.priority;
        case 'duration':
          return b.duration - a.duration;
        case 'resources':
          return b.resourceCount - a.resourceCount;
        default:
          return 0;
      }
    });

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4">
          <h2 className="text-xl font-bold text-gray-900">
            {showGlobalPriority ? 'Global Priority Task Queue' : 'Individual Aircraft Task Queue'}
          </h2>
          <button
            onClick={() => setShowGlobalPriority(!showGlobalPriority)}
            className="px-3 py-1 text-sm bg-navy-600 text-white rounded-lg hover:bg-navy-700 transition-colors"
          >
            {showGlobalPriority ? 'Show Individual' : 'Show Global'}
          </button>
        </div>
        <div className="text-sm text-gray-500">
          {filteredTasks.length} of {tasks.length} tasks
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Search tasks..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-navy-500 focus:border-navy-500"
          />
        </div>
        
        <div className="flex space-x-2">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-navy-500 focus:border-navy-500"
          >
            <option value="all">All Status</option>
            <option value="not_started">Not Started</option>
            <option value="in_progress">In Progress</option>
            <option value="completed">Completed</option>
            <option value="blocked">Blocked</option>
          </select>
          
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-navy-500 focus:border-navy-500"
          >
            <option value="global_priority">Global Priority</option>
            <option value="priority">Priority</option>
            <option value="duration">Duration</option>
            <option value="resources">Resources</option>
          </select>
        </div>
      </div>

      {/* Task Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTasks.map(task => {
          const taskAircraft = getAircraftForTask(task.aircraftId);
          if (!taskAircraft) return null;
          
          return (
            <TaskCard
              key={task.id}
              task={task}
              aircraft={taskAircraft}
              onClick={() => {
                // In real app, would open task details modal
                console.log('Task clicked:', task.id);
              }}
            />
          );
        })}
      </div>

      {filteredTasks.length === 0 && (
        <div className="text-center py-12">
          <Filter className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500">No tasks match your current filters</p>
        </div>
      )}
    </div>
  );
};