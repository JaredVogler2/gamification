import React, { useState } from 'react';
import { 
  TrendingUp, 
  Calendar, 
  DollarSign, 
  Clock, 
  Target, 
  AlertCircle, 
  Info,
  BarChart3,
  Zap
} from 'lucide-react';

export const EVMGuide: React.FC = () => {
  const [activeSection, setActiveSection] = useState('overview');

  // Mock data for the performance chart
  const performanceData = [
    { week: 'Week 1', plannedValue: 500000, earnedValue: 480000, actualCost: 520000 },
    { week: 'Week 2', plannedValue: 1200000, earnedValue: 1150000, actualCost: 1180000 },
    { week: 'Week 3', plannedValue: 1800000, earnedValue: 1720000, actualCost: 1850000 },
    { week: 'Week 4', plannedValue: 2500000, earnedValue: 2380000, actualCost: 2600000 },
    { week: 'Week 5', plannedValue: 3200000, earnedValue: 3050000, actualCost: 3300000 },
    { week: 'Week 6', plannedValue: 3900000, earnedValue: 3720000, actualCost: 4000000 },
    { week: 'Week 7', plannedValue: 4600000, earnedValue: 4400000, actualCost: 4700000 },
    { week: 'Week 8', plannedValue: 5300000, earnedValue: 5100000, actualCost: 5400000 },
  ];

  const maxValue = Math.max(...performanceData.map(d => Math.max(d.plannedValue, d.earnedValue, d.actualCost)));
  const chartHeight = 300;

  const sections = [
    { id: 'overview', label: 'EVM Overview', icon: Info },
    { id: 'spi', label: 'Schedule Performance', icon: Calendar },
    { id: 'float', label: 'Schedule Float', icon: Clock },
    { id: 'chart', label: 'Performance Chart', icon: BarChart3 },
  ];

  const renderOverview = () => (
    <div className="space-y-6">
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h3 className="text-xl font-bold text-blue-900 mb-4">What is Earned Value Management?</h3>
        <p className="text-blue-800 mb-4">
          Earned Value Management (EVM) is a project management technique that integrates scope, schedule, and cost data 
          to provide objective performance measurement and forecasting capabilities.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <Target className="w-5 h-5 text-green-600" />
              <h4 className="font-semibold text-gray-900">Planned Value (PV)</h4>
            </div>
            <p className="text-sm text-gray-600">
              The authorized budget assigned to work scheduled to be accomplished for an activity or work breakdown structure component.
            </p>
          </div>
          <div className="bg-white p-4 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <TrendingUp className="w-5 h-5 text-blue-600" />
              <h4 className="font-semibold text-gray-900">Earned Value (EV)</h4>
            </div>
            <p className="text-sm text-gray-600">
              The measure of work performed expressed in terms of the budget authorized for that work.
            </p>
          </div>
          <div className="bg-white p-4 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <DollarSign className="w-5 h-5 text-red-600" />
              <h4 className="font-semibold text-gray-900">Actual Cost (AC)</h4>
            </div>
            <p className="text-sm text-gray-600">
              The realized cost incurred for the work performed on an activity during a specific time period.
            </p>
          </div>
        </div>
      </div>
    </div>
  );

  const renderSPI = () => (
    <div className="space-y-6">
      <div className="bg-white rounded-lg border p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Schedule Performance Index (SPI)</h3>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <h4 className="font-semibold text-blue-900 mb-2">Formula</h4>
              <div className="text-2xl font-bold text-blue-800 text-center py-4 bg-white rounded border">
                SPI = EV ÷ PV
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <div className="w-4 h-4 bg-green-500 rounded-full"></div>
                <span className="text-sm"><strong>SPI &gt; 1.0:</strong> Ahead of schedule</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-4 h-4 bg-yellow-500 rounded-full"></div>
                <span className="text-sm"><strong>SPI = 1.0:</strong> On schedule</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-4 h-4 bg-red-500 rounded-full"></div>
                <span className="text-sm"><strong>SPI &lt; 1.0:</strong> Behind schedule</span>
              </div>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold text-gray-900 mb-3">Real-World Example</h4>
            <div className="bg-gray-50 p-4 rounded-lg space-y-2">
              <div className="text-sm">
                <strong>Planned Value (PV):</strong> $3,200,000
              </div>
              <div className="text-sm">
                <strong>Earned Value (EV):</strong> $3,050,000
              </div>
              <div className="text-sm">
                <strong>SPI Calculation:</strong> $3,050,000 ÷ $3,200,000 = 0.95
              </div>
              <div className="text-sm font-semibold text-red-600">
                Result: 5% behind schedule
              </div>
            </div>
            
            <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded">
              <div className="flex items-start space-x-2">
                <AlertCircle className="w-4 h-4 text-yellow-600 mt-0.5" />
                <div className="text-sm text-yellow-800">
                  <strong>Impact:</strong> This aircraft is running behind schedule and may miss its pulse date or delivery commitment.
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-lg border p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Cost Performance Index (CPI)</h3>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <div className="bg-green-50 p-4 rounded-lg mb-4">
              <h4 className="font-semibold text-green-900 mb-2">Formula</h4>
              <div className="text-2xl font-bold text-green-800 text-center py-4 bg-white rounded border">
                CPI = EV ÷ AC
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <div className="w-4 h-4 bg-green-500 rounded-full"></div>
                <span className="text-sm"><strong>CPI &gt; 1.0:</strong> Under budget</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-4 h-4 bg-yellow-500 rounded-full"></div>
                <span className="text-sm"><strong>CPI = 1.0:</strong> On budget</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-4 h-4 bg-red-500 rounded-full"></div>
                <span className="text-sm"><strong>CPI &lt; 1.0:</strong> Over budget</span>
              </div>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold text-gray-900 mb-3">Real-World Example</h4>
            <div className="bg-gray-50 p-4 rounded-lg space-y-2">
              <div className="text-sm">
                <strong>Earned Value (EV):</strong> $3,050,000
              </div>
              <div className="text-sm">
                <strong>Actual Cost (AC):</strong> $3,300,000
              </div>
              <div className="text-sm">
                <strong>CPI Calculation:</strong> $3,050,000 ÷ $3,300,000 = 0.92
              </div>
              <div className="text-sm font-semibold text-red-600">
                Result: 8% over budget
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderFloat = () => (
    <div className="space-y-6">
      <div className="bg-white rounded-lg border p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Schedule Float (Slack)</h3>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <p className="text-gray-600 mb-4">
              Float is the amount of time that a task can be delayed without delaying the project finish date or violating a schedule constraint.
            </p>
            
            <div className="space-y-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-semibold text-blue-900 mb-2">Total Float</h4>
                <p className="text-sm text-blue-800">
                  The amount of time an activity can be delayed without delaying the project completion date.
                </p>
                <div className="mt-2 text-xs text-blue-700 font-mono">
                  Total Float = Late Start - Early Start
                </div>
              </div>
              
              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="font-semibold text-green-900 mb-2">Free Float</h4>
                <p className="text-sm text-green-800">
                  The amount of time an activity can be delayed without delaying the early start of any successor activity.
                </p>
                <div className="mt-2 text-xs text-green-700 font-mono">
                  Free Float = Early Start of Successor - Early Finish of Current
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold text-gray-900 mb-3">Aircraft Production Example</h4>
            <div className="space-y-3">
              <div className="bg-red-50 border border-red-200 p-3 rounded">
                <div className="flex items-center space-x-2 mb-1">
                  <Target className="w-4 h-4 text-red-600" />
                  <span className="font-medium text-red-900">Critical Path Tasks</span>
                </div>
                <div className="text-sm text-red-800">Float = 0 days</div>
                <div className="text-xs text-red-700 mt-1">
                  Wing assembly, engine installation, final inspection
                </div>
              </div>
              
              <div className="bg-yellow-50 border border-yellow-200 p-3 rounded">
                <div className="flex items-center space-x-2 mb-1">
                  <Clock className="w-4 h-4 text-yellow-600" />
                  <span className="font-medium text-yellow-900">Non-Critical Tasks</span>
                </div>
                <div className="text-sm text-yellow-800">Float = 2-5 days</div>
                <div className="text-xs text-yellow-700 mt-1">
                  Interior fitting, auxiliary systems, documentation
                </div>
              </div>
              
              <div className="bg-gray-50 border border-gray-200 p-3 rounded">
                <div className="flex items-center space-x-2 mb-1">
                  <Zap className="w-4 h-4 text-gray-600" />
                  <span className="font-medium text-gray-900">Buffer Tasks</span>
                </div>
                <div className="text-sm text-gray-800">Float = 7+ days</div>
                <div className="text-xs text-gray-700 mt-1">
                  Optional modifications, early preparation work
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg border p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Using Float for Priority Decisions</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-red-50 p-4 rounded-lg">
            <h4 className="font-semibold text-red-900 mb-2">Zero Float (Critical)</h4>
            <ul className="text-sm text-red-800 space-y-1">
              <li>• Highest priority</li>
              <li>• Cannot be delayed</li>
              <li>• Direct impact on delivery</li>
              <li>• Requires immediate attention</li>
            </ul>
          </div>
          
          <div className="bg-yellow-50 p-4 rounded-lg">
            <h4 className="font-semibold text-yellow-900 mb-2">Low Float (1-3 days)</h4>
            <ul className="text-sm text-yellow-800 space-y-1">
              <li>• High priority</li>
              <li>• Monitor closely</li>
              <li>• May become critical</li>
              <li>• Plan contingencies</li>
            </ul>
          </div>
          
          <div className="bg-green-50 p-4 rounded-lg">
            <h4 className="font-semibold text-green-900 mb-2">High Float (4+ days)</h4>
            <ul className="text-sm text-green-800 space-y-1">
              <li>• Lower priority</li>
              <li>• Flexible scheduling</li>
              <li>• Resource reallocation</li>
              <li>• Buffer for issues</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );

  const renderChart = () => (
    <div className="space-y-6">
      <div className="bg-white rounded-lg border p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Earned Value Performance Over Time</h3>
        
        <div className="mb-6">
          <div className="flex items-center space-x-6 mb-4">
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-green-500 rounded"></div>
              <span className="text-sm font-medium">Planned Value (PV)</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-blue-500 rounded"></div>
              <span className="text-sm font-medium">Earned Value (EV)</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-red-500 rounded"></div>
              <span className="text-sm font-medium">Actual Cost (AC)</span>
            </div>
          </div>
          
          {/* Chart Container */}
          <div className="relative" style={{ height: `${chartHeight}px` }}>
            <svg width="100%" height={chartHeight} className="border rounded">
              {/* Grid lines */}
              {[0, 0.2, 0.4, 0.6, 0.8, 1.0].map((ratio, index) => (
                <line
                  key={index}
                  x1="60"
                  y1={chartHeight - 40 - (ratio * (chartHeight - 80))}
                  x2="100%"
                  y2={chartHeight - 40 - (ratio * (chartHeight - 80))}
                  stroke="#e5e7eb"
                  strokeWidth="1"
                />
              ))}
              
              {/* Y-axis labels */}
              {[0, 0.2, 0.4, 0.6, 0.8, 1.0].map((ratio, index) => (
                <text
                  key={index}
                  x="45"
                  y={chartHeight - 35 - (ratio * (chartHeight - 80))}
                  fontSize="12"
                  fill="#6b7280"
                  textAnchor="end"
                >
                  ${((maxValue * ratio) / 1000000).toFixed(1)}M
                </text>
              ))}
              
              {/* Chart lines */}
              {/* Planned Value line */}
              <polyline
                fill="none"
                stroke="#10b981"
                strokeWidth="3"
                points={performanceData.map((d, i) => 
                  `${60 + (i * ((800) / (performanceData.length - 1)))},${
                    chartHeight - 40 - ((d.plannedValue / maxValue) * (chartHeight - 80))
                  }`
                ).join(' ')}
              />
              
              {/* Earned Value line */}
              <polyline
                fill="none"
                stroke="#3b82f6"
                strokeWidth="3"
                points={performanceData.map((d, i) => 
                  `${60 + (i * ((800) / (performanceData.length - 1)))},${
                    chartHeight - 40 - ((d.earnedValue / maxValue) * (chartHeight - 80))
                  }`
                ).join(' ')}
              />
              
              {/* Actual Cost line */}
              <polyline
                fill="none"
                stroke="#ef4444"
                strokeWidth="3"
                points={performanceData.map((d, i) => 
                  `${60 + (i * ((800) / (performanceData.length - 1)))},${
                    chartHeight - 40 - ((d.actualCost / maxValue) * (chartHeight - 80))
                  }`
                ).join(' ')}
              />
              
              {/* Data points */}
              {performanceData.map((d, i) => (
                <g key={i}>
                  <circle
                    cx={60 + (i * ((800) / (performanceData.length - 1)))}
                    cy={chartHeight - 40 - ((d.plannedValue / maxValue) * (chartHeight - 80))}
                    r="4"
                    fill="#10b981"
                  />
                  <circle
                    cx={60 + (i * ((800) / (performanceData.length - 1)))}
                    cy={chartHeight - 40 - ((d.earnedValue / maxValue) * (chartHeight - 80))}
                    r="4"
                    fill="#3b82f6"
                  />
                  <circle
                    cx={60 + (i * ((800) / (performanceData.length - 1)))}
                    cy={chartHeight - 40 - ((d.actualCost / maxValue) * (chartHeight - 80))}
                    r="4"
                    fill="#ef4444"
                  />
                </g>
              ))}
              
              {/* X-axis labels */}
              {performanceData.map((d, i) => (
                <text
                  key={i}
                  x={60 + (i * ((800) / (performanceData.length - 1)))}
                  y={chartHeight - 15}
                  fontSize="12"
                  fill="#6b7280"
                  textAnchor="middle"
                >
                  {d.week}
                </text>
              ))}
            </svg>
          </div>
        </div>
        
        {/* Performance Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
          <div className="bg-blue-50 p-4 rounded-lg">
            <h4 className="font-semibold text-blue-900 mb-2">Current Status</h4>
            <div className="space-y-1 text-sm text-blue-800">
              <div>SPI: 0.96 (4% behind schedule)</div>
              <div>CPI: 0.94 (6% over budget)</div>
              <div>Schedule Variance: -$150,000</div>
            </div>
          </div>
          
          <div className="bg-yellow-50 p-4 rounded-lg">
            <h4 className="font-semibold text-yellow-900 mb-2">Trend Analysis</h4>
            <div className="space-y-1 text-sm text-yellow-800">
              <div>Performance declining over time</div>
              <div>Gap widening between PV and EV</div>
              <div>Cost overruns accelerating</div>
            </div>
          </div>
          
          <div className="bg-red-50 p-4 rounded-lg">
            <h4 className="font-semibold text-red-900 mb-2">Action Required</h4>
            <div className="space-y-1 text-sm text-red-800">
              <div>Implement corrective measures</div>
              <div>Increase resource allocation</div>
              <div>Review critical path tasks</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activeSection) {
      case 'overview': return renderOverview();
      case 'spi': return renderSPI();
      case 'float': return renderFloat();
      case 'chart': return renderChart();
      default: return renderOverview();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Earned Value Management Guide</h1>
        <div className="text-sm text-gray-500">
          Performance measurement fundamentals for aircraft manufacturing
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Navigation Sidebar */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-lg p-4">
            <h3 className="font-semibold text-gray-900 mb-4">Topics</h3>
            <nav className="space-y-2">
              {sections.map(section => {
                const Icon = section.icon;
                return (
                  <button
                    key={section.id}
                    onClick={() => setActiveSection(section.id)}
                    className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                      activeSection === section.id
                        ? 'bg-navy-600 text-white'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span className="text-sm font-medium">{section.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3">
          {renderContent()}
        </div>
      </div>
    </div>
  );
};