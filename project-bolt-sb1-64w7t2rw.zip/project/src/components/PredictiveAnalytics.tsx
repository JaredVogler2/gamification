import React, { useState, useMemo } from 'react';
import { Aircraft, ProductionMetrics } from '../types';
import { TrendingUp, Calendar, Clock, Zap, AlertTriangle, Target, Users, Activity } from 'lucide-react';

interface PredictiveAnalyticsProps {
  aircraft: Aircraft[];
  metrics: ProductionMetrics;
}

interface PredictionScenario {
  overtimePercentage: number;
  laborEfficiencyImprovement: number;
  additionalResources: number;
}

interface AircraftPrediction {
  aircraftId: string;
  currentDeliveryDate: Date;
  predictedDeliveryDate: Date;
  deliveryVariance: number; // days
  confidenceLevel: number; // 0-1
  criticalPathRisk: number; // 0-1
  resourceBottlenecks: string[];
  remainingWork: number; // hours
  probabilityOnTime: number; // 0-1
}

export const PredictiveAnalytics: React.FC<PredictiveAnalyticsProps> = ({ aircraft, metrics }) => {
  const [scenario, setScenario] = useState<PredictionScenario>({
    overtimePercentage: 0,
    laborEfficiencyImprovement: 0,
    additionalResources: 0
  });

  const predictions = useMemo(() => {
    return aircraft.map(ac => {
      const spi = ac.earnedValue / ac.plannedValue;
      const cpi = ac.earnedValue / ac.actualCost;
      const completionRate = ac.completedTasks / ac.totalTasks;
      const remainingTasks = ac.totalTasks - ac.completedTasks;
      
      // Calculate remaining days based on typical 70-day cycle
      const expectedTotalDays = 70;
      const baseRemainingDays = expectedTotalDays * (1 - completionRate);
      
      // Apply scenario adjustments
      const efficiencyMultiplier = 1 + (scenario.laborEfficiencyImprovement / 100);
      const overtimeMultiplier = 1 + (scenario.overtimePercentage / 100) * 0.6; // Overtime has diminishing returns
      const resourceMultiplier = 1 + (scenario.additionalResources / 100) * 0.8; // Resource scaling efficiency
      
      // Apply performance adjustments based on SPI
      const performanceAdjustment = 1 / Math.max(0.5, spi); // Poor performance extends timeline
      let adjustedRemainingDays = baseRemainingDays * performanceAdjustment;
      
      // Apply scenario improvements
      adjustedRemainingDays = adjustedRemainingDays / (efficiencyMultiplier * overtimeMultiplier * resourceMultiplier);
      
      // Cap the maximum delay at 30 days beyond normal schedule
      adjustedRemainingDays = Math.min(adjustedRemainingDays, baseRemainingDays + 30);
      
      const calendarDays = Math.ceil(adjustedRemainingDays);
      
      const predictedDeliveryDate = new Date();
      predictedDeliveryDate.setDate(predictedDeliveryDate.getDate() + calendarDays);
      
      const deliveryVariance = Math.ceil((predictedDeliveryDate.getTime() - ac.deliveryDate.getTime()) / (1000 * 60 * 60 * 24));
      
      // Calculate confidence based on historical performance and completion rate
      const performanceStability = Math.min(spi, cpi) * (0.5 + completionRate * 0.5);
      const confidenceLevel = Math.max(0.65, Math.min(0.95, performanceStability * 0.85 + 0.15));
      
      // Critical path risk assessment
      const criticalPathRisk = Math.max(0, Math.min(0.9, (1 - spi) * (1 - completionRate * 0.7)));
      
      // Probability of on-time delivery
      const probabilityOnTime = Math.max(0.05, Math.min(0.98, 
        (spi * cpi * confidenceLevel * 0.9) - (Math.max(0, deliveryVariance) * 0.015)
      ));

      return {
        aircraftId: ac.id,
        currentDeliveryDate: ac.deliveryDate,
        predictedDeliveryDate,
        deliveryVariance,
        confidenceLevel,
        criticalPathRisk,
        resourceBottlenecks: ['Wing Assembly', 'Hydraulic Testing', 'Interior Fitting'],
        remainingWork: adjustedRemainingDays * 8, // Convert to hours for display
        probabilityOnTime
      } as AircraftPrediction;
    });
  }, [aircraft, metrics, scenario]);

  const overallMetrics = useMemo(() => {
    const onTimeDeliveries = predictions.filter(p => p.deliveryVariance <= 0).length;
    const averageVariance = predictions.reduce((sum, p) => sum + p.deliveryVariance, 0) / predictions.length;
    const averageConfidence = predictions.reduce((sum, p) => sum + p.confidenceLevel, 0) / predictions.length;
    const highRiskAircraft = predictions.filter(p => p.criticalPathRisk > 0.7).length;
    
    return {
      onTimeDeliveries,
      averageVariance,
      averageConfidence,
      highRiskAircraft,
      totalAircraft: predictions.length
    };
  }, [predictions]);

  const getVarianceColor = (variance: number) => {
    if (variance <= 0) return 'text-green-600 bg-green-100';
    if (variance <= 3) return 'text-yellow-600 bg-yellow-100';
    if (variance <= 7) return 'text-orange-600 bg-orange-100';
    return 'text-red-600 bg-red-100';
  };

  const getRiskColor = (risk: number) => {
    if (risk <= 0.3) return 'text-green-600 bg-green-100';
    if (risk <= 0.6) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  return (
    <div className="space-y-6">
      {/* Scenario Controls */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center space-x-2 mb-6">
          <Activity className="w-6 h-6 text-blue-500" />
          <h2 className="text-xl font-bold text-gray-900">Scenario Planning & What-If Analysis</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Overtime Increase (%)
            </label>
            <div className="relative">
              <input
                type="range"
                min="0"
                max="50"
                step="5"
                value={scenario.overtimePercentage}
                onChange={(e) => setScenario(prev => ({ ...prev, overtimePercentage: parseInt(e.target.value) }))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>0%</span>
                <span className="font-medium text-blue-600">{scenario.overtimePercentage}%</span>
                <span>50%</span>
              </div>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Labor Efficiency Improvement (%)
            </label>
            <div className="relative">
              <input
                type="range"
                min="0"
                max="30"
                step="2"
                value={scenario.laborEfficiencyImprovement}
                onChange={(e) => setScenario(prev => ({ ...prev, laborEfficiencyImprovement: parseInt(e.target.value) }))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>0%</span>
                <span className="font-medium text-green-600">{scenario.laborEfficiencyImprovement}%</span>
                <span>30%</span>
              </div>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Additional Resources (%)
            </label>
            <div className="relative">
              <input
                type="range"
                min="0"
                max="40"
                step="5"
                value={scenario.additionalResources}
                onChange={(e) => setScenario(prev => ({ ...prev, additionalResources: parseInt(e.target.value) }))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>0%</span>
                <span className="font-medium text-purple-600">{scenario.additionalResources}%</span>
                <span>40%</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Scenario Impact Summary */}
        <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-gray-50 rounded-lg">
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">
              {overallMetrics.onTimeDeliveries}/{overallMetrics.totalAircraft}
            </div>
            <div className="text-xs text-gray-600">On-Time Deliveries</div>
          </div>
          <div className="text-center">
            <div className={`text-2xl font-bold ${overallMetrics.averageVariance <= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {overallMetrics.averageVariance > 0 ? '+' : ''}{overallMetrics.averageVariance.toFixed(1)}
            </div>
            <div className="text-xs text-gray-600">Avg Variance (days)</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">
              {(overallMetrics.averageConfidence * 100).toFixed(0)}%
            </div>
            <div className="text-xs text-gray-600">Avg Confidence</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600">
              {overallMetrics.highRiskAircraft}
            </div>
            <div className="text-xs text-gray-600">High Risk Aircraft</div>
          </div>
        </div>
      </div>

      {/* Detailed Predictions Table */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center space-x-2 mb-6">
          <Target className="w-6 h-6 text-green-500" />
          <h2 className="text-xl font-bold text-gray-900">Delivery Date Predictions</h2>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Aircraft</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Current Target</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Predicted Date</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Variance</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Confidence</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">On-Time Prob.</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Critical Risk</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Remaining Work</th>
              </tr>
            </thead>
            <tbody>
              {predictions.map((prediction, index) => {
                const ac = aircraft.find(a => a.id === prediction.aircraftId);
                if (!ac) return null;
                
                return (
                  <tr key={prediction.aircraftId} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <div className="font-medium text-gray-900">{ac.serialNumber}</div>
                      <div className="text-xs text-gray-500">
                        {((ac.completedTasks / ac.totalTasks) * 100).toFixed(1)}% complete
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="text-sm text-gray-900">
                        {prediction.currentDeliveryDate.toLocaleDateString()}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="text-sm font-medium text-gray-900">
                        {prediction.predictedDeliveryDate.toLocaleDateString()}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getVarianceColor(prediction.deliveryVariance)}`}>
                        {prediction.deliveryVariance > 0 ? '+' : ''}{prediction.deliveryVariance} days
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center space-x-2">
                        <div className="text-sm font-medium">
                          {(prediction.confidenceLevel * 100).toFixed(0)}%
                        </div>
                        <div className="w-16 bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${
                              prediction.confidenceLevel >= 0.8 ? 'bg-green-500' :
                              prediction.confidenceLevel >= 0.6 ? 'bg-yellow-500' : 'bg-red-500'
                            }`}
                            style={{ width: `${prediction.confidenceLevel * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className={`text-sm font-bold ${
                        prediction.probabilityOnTime >= 0.8 ? 'text-green-600' :
                        prediction.probabilityOnTime >= 0.6 ? 'text-yellow-600' : 'text-red-600'
                      }`}>
                        {(prediction.probabilityOnTime * 100).toFixed(0)}%
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getRiskColor(prediction.criticalPathRisk)}`}>
                        {prediction.criticalPathRisk <= 0.3 ? 'Low' :
                         prediction.criticalPathRisk <= 0.6 ? 'Medium' : 'High'}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="text-sm text-gray-900">
                        {prediction.remainingWork.toFixed(0)}h
                      </div>
                      <div className="text-xs text-gray-500">
                        {Math.ceil(prediction.remainingWork / 8)} days
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Risk Analysis & Recommendations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center space-x-2 mb-4">
            <AlertTriangle className="w-5 h-5 text-red-500" />
            <h2 className="text-lg font-bold text-gray-900">High-Risk Aircraft</h2>
          </div>
          <div className="space-y-3">
            {predictions
              .filter(p => p.criticalPathRisk > 0.6 || p.deliveryVariance > 5)
              .map(prediction => {
                const ac = aircraft.find(a => a.id === prediction.aircraftId);
                if (!ac) return null;
                
                return (
                  <div key={prediction.aircraftId} className="p-3 bg-red-50 rounded-lg">
                    <div className="flex justify-between items-start mb-2">
                      <span className="font-medium text-red-800">{ac.serialNumber}</span>
                      <span className="text-red-600 text-sm font-bold">
                        +{prediction.deliveryVariance} days
                      </span>
                    </div>
                    <div className="text-sm text-red-700">
                      Critical Path Risk: {(prediction.criticalPathRisk * 100).toFixed(0)}%
                    </div>
                    <div className="text-xs text-gray-600 mt-1">
                      Bottlenecks: {prediction.resourceBottlenecks.join(', ')}
                    </div>
                  </div>
                );
              })}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center space-x-2 mb-4">
            <Zap className="w-5 h-5 text-green-500" />
            <h2 className="text-lg font-bold text-gray-900">Recovery Actions</h2>
          </div>
          <div className="space-y-3 text-sm">
            <div className="p-3 bg-blue-50 rounded-lg">
              <div className="font-medium text-blue-800 mb-1">
                Increase Overtime to {scenario.overtimePercentage + 10}%
              </div>
              <div className="text-blue-700">
                Could recover average of {Math.abs(overallMetrics.averageVariance * 0.3).toFixed(1)} days
              </div>
            </div>
            
            <div className="p-3 bg-green-50 rounded-lg">
              <div className="font-medium text-green-800 mb-1">
                Focus on Efficiency Training
              </div>
              <div className="text-green-700">
                5% efficiency improvement = {Math.abs(overallMetrics.averageVariance * 0.4).toFixed(1)} day recovery
              </div>
            </div>
            
            <div className="p-3 bg-purple-50 rounded-lg">
              <div className="font-medium text-purple-800 mb-1">
                Add Swing Shift Resources
              </div>
              <div className="text-purple-700">
                15% more resources could improve delivery by {Math.abs(overallMetrics.averageVariance * 0.25).toFixed(1)} days
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};