import React from 'react';
import { Aircraft, ProductionMetrics } from '../types';
import { PredictiveAnalytics } from './PredictiveAnalytics';
import { TrendingUp, TrendingDown, AlertTriangle, CheckCircle, Clock, DollarSign } from 'lucide-react';

interface VPDashboardProps {
  aircraft: Aircraft[];
  metrics: ProductionMetrics;
}

export const VPDashboard: React.FC<VPDashboardProps> = ({ aircraft, metrics }) => {
  const totalAircraft = aircraft.length;
  const onTimeAircraft = aircraft.filter(ac => {
    const now = new Date();
    return ac.expectedPulseDate.getTime() > now.getTime();
  }).length;

  const avgSPI = aircraft.reduce((sum, ac) => sum + (ac.earnedValue / ac.plannedValue), 0) / totalAircraft;
  const avgCPI = aircraft.reduce((sum, ac) => sum + (ac.earnedValue / ac.actualCost), 0) / totalAircraft;

  const MetricCard = ({ title, value, change, icon: Icon, color }: any) => (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-gray-600 text-sm font-medium">{title}</p>
          <p className="text-2xl font-bold text-gray-900 mt-1">{value}</p>
          {change && (
            <div className={`flex items-center mt-2 text-sm ${change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {change >= 0 ? <TrendingUp className="w-4 h-4 mr-1" /> : <TrendingDown className="w-4 h-4 mr-1" />}
              <span>{Math.abs(change)}% vs last week</span>
            </div>
          )}
        </div>
        <div className={`p-3 rounded-full ${color}`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Production Health Dashboard</h1>
        <div className="text-sm text-gray-500">
          Last updated: {new Date().toLocaleString()}
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="On-Time Delivery"
          value={`${Math.round((onTimeAircraft / totalAircraft) * 100)}%`}
          change={5.2}
          icon={CheckCircle}
          color="bg-green-500"
        />
        <MetricCard
          title="Schedule Performance"
          value={avgSPI.toFixed(2)}
          change={avgSPI >= 1.0 ? 2.1 : -1.8}
          icon={Clock}
          color={avgSPI >= 1.0 ? "bg-green-500" : "bg-red-500"}
        />
        <MetricCard
          title="Cost Performance"
          value={avgCPI.toFixed(2)}
          change={avgCPI >= 1.0 ? 1.5 : -3.2}
          icon={DollarSign}
          color={avgCPI >= 1.0 ? "bg-green-500" : "bg-red-500"}
        />
        <MetricCard
          title="Tasks Today"
          value={metrics.tasksCompletedToday}
          change={8.7}
          icon={TrendingUp}
          color="bg-blue-500"
        />
      </div>

      {/* Aircraft Summary Grid */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Aircraft At-A-Glance</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Aircraft</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Position</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Progress</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Schedule</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Days to Pulse</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">SPI</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">CPI</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Risk Status</th>
              </tr>
            </thead>
            <tbody>
              {aircraft.map(ac => {
                const completionPercentage = (ac.completedTasks / ac.totalTasks) * 100;
                const now = new Date();
                const daysToPulse = Math.ceil((ac.expectedPulseDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
                const daysToDelivery = Math.ceil((ac.deliveryDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
                const spi = ac.earnedValue / ac.plannedValue;
                const cpi = ac.earnedValue / ac.actualCost;
                
                // Determine schedule status
                let scheduleStatus = 'On Track';
                let scheduleColor = 'text-green-600 bg-green-100';
                if (daysToPulse < 0) {
                  scheduleStatus = 'Overdue';
                  scheduleColor = 'text-red-600 bg-red-100';
                } else if (daysToPulse <= 1) {
                  scheduleStatus = 'Critical';
                  scheduleColor = 'text-orange-600 bg-orange-100';
                } else if (spi < 0.9) {
                  scheduleStatus = 'Behind';
                  scheduleColor = 'text-yellow-600 bg-yellow-100';
                }
                
                // Determine risk status
                let riskStatus = 'Low';
                let riskColor = 'text-green-600 bg-green-100';
                if (spi < 0.8 || cpi < 0.8 || daysToPulse < 0) {
                  riskStatus = 'High';
                  riskColor = 'text-red-600 bg-red-100';
                } else if (spi < 0.9 || cpi < 0.9 || daysToPulse <= 1) {
                  riskStatus = 'Medium';
                  riskColor = 'text-orange-600 bg-orange-100';
                }
                
                return (
                  <tr key={ac.id} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <div className="font-medium text-gray-900">{ac.serialNumber}</div>
                      <div className="text-xs text-gray-500">Entry: {ac.entryDate.toLocaleDateString()}</div>
                    </td>
                    <td className="py-3 px-4">
                      <div className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        ac.currentPosition === -1 ? 'bg-purple-100 text-purple-800' :
                        ac.currentPosition === 0 ? 'bg-blue-100 text-blue-800' :
                        ac.currentPosition === 1 ? 'bg-green-100 text-green-800' :
                        ac.currentPosition === 2 ? 'bg-yellow-100 text-yellow-800' :
                        ac.currentPosition === 3 ? 'bg-orange-100 text-orange-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {ac.currentPosition === -1 ? 'FGI' : `Pos ${ac.currentPosition}`}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center space-x-2">
                        <div className="flex-1">
                          <div className="text-sm font-medium text-gray-900">{completionPercentage.toFixed(1)}%</div>
                          <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                            <div 
                              className={`h-2 rounded-full transition-all duration-300 ${
                                completionPercentage >= 90 ? 'bg-green-500' :
                                completionPercentage >= 70 ? 'bg-yellow-500' : 'bg-red-500'
                              }`}
                              style={{ width: `${completionPercentage}%` }}
                            ></div>
                          </div>
                        </div>
                        <div className="text-xs text-gray-500">
                          {ac.completedTasks}/{ac.totalTasks}
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${scheduleColor}`}>
                        {scheduleStatus}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className={`text-sm font-medium ${
                        daysToPulse < 0 ? 'text-red-600' :
                        daysToPulse <= 1 ? 'text-orange-600' :
                        daysToPulse <= 2 ? 'text-yellow-600' : 'text-gray-900'
                      }`}>
                        {daysToPulse < 0 ? `${Math.abs(daysToPulse)} overdue` : `${daysToPulse} days`}
                      </div>
                      <div className="text-xs text-gray-500">
                        Delivery: {daysToDelivery} days
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`text-sm font-bold ${
                        spi >= 1.0 ? 'text-green-600' : 
                        spi >= 0.9 ? 'text-yellow-600' : 'text-red-600'
                      }`}>
                        {spi.toFixed(2)}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`text-sm font-bold ${
                        cpi >= 1.0 ? 'text-green-600' : 
                        cpi >= 0.9 ? 'text-yellow-600' : 'text-red-600'
                      }`}>
                        {cpi.toFixed(2)}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${riskColor}`}>
                        {riskStatus}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        
        {/* Summary Stats */}
        <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-gray-200">
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">
              {aircraft.filter(ac => {
                const daysToPulse = Math.ceil((ac.expectedPulseDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
                return daysToPulse >= 0 && (ac.earnedValue / ac.plannedValue) >= 0.9;
              }).length}
            </div>
            <div className="text-xs text-gray-600">On Track</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-yellow-600">
              {aircraft.filter(ac => {
                const daysToPulse = Math.ceil((ac.expectedPulseDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
                const spi = ac.earnedValue / ac.plannedValue;
                return daysToPulse >= 0 && spi < 0.9 && spi >= 0.8;
              }).length}
            </div>
            <div className="text-xs text-gray-600">At Risk</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600">
              {aircraft.filter(ac => {
                const daysToPulse = Math.ceil((ac.expectedPulseDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
                return daysToPulse <= 1 && daysToPulse >= 0;
              }).length}
            </div>
            <div className="text-xs text-gray-600">Critical</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-red-600">
              {aircraft.filter(ac => {
                const daysToPulse = Math.ceil((ac.expectedPulseDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
                return daysToPulse < 0;
              }).length}
            </div>
            <div className="text-xs text-gray-600">Overdue</div>
          </div>
        </div>
      </div>
      {/* Aircraft Status Grid */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Aircraft Status Overview</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {aircraft.map(ac => {
            const completionPercentage = (ac.completedTasks / ac.totalTasks) * 100;
            const isOnTime = ac.expectedPulseDate.getTime() > new Date().getTime();
            const spi = ac.earnedValue / ac.plannedValue;
            const cpi = ac.earnedValue / ac.actualCost;
            
            return (
              <div key={ac.id} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-gray-900">{ac.serialNumber}</h3>
                  <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                    isOnTime ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {isOnTime ? 'On Track' : 'At Risk'}
                  </div>
                </div>
                
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Position:</span>
                    <span className="font-medium">{ac.currentPosition === -1 ? 'FGI' : `Pos ${ac.currentPosition}`}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Progress:</span>
                    <span className="font-medium">{completionPercentage.toFixed(1)}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">SPI:</span>
                    <span className={`font-medium ${spi >= 1.0 ? 'text-green-600' : 'text-red-600'}`}>
                      {spi.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">CPI:</span>
                    <span className={`font-medium ${cpi >= 1.0 ? 'text-green-600' : 'text-red-600'}`}>
                      {cpi.toFixed(2)}
                    </span>
                  </div>
                </div>
                
                <div className="mt-3">
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full transition-all duration-500 ${
                        completionPercentage >= 90 ? 'bg-green-500' :
                        completionPercentage >= 70 ? 'bg-yellow-500' : 'bg-red-500'
                      }`}
                      style={{ width: `${completionPercentage}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Predictive Analytics Section */}
      <PredictiveAnalytics aircraft={aircraft} metrics={metrics} />

      {/* Bottlenecks and Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center space-x-2 mb-4">
            <AlertTriangle className="w-5 h-5 text-red-500" />
            <h2 className="text-lg font-bold text-gray-900">Current Bottlenecks</h2>
          </div>
          <div className="space-y-3">
            {metrics.bottleneckAreas.map((area, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                <span className="font-medium text-red-800">{area}</span>
                <span className="text-red-600 text-sm">High Impact</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-lg font-bold text-gray-900 mb-4">Resource Utilization</h2>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-600">Worker Utilization</span>
                <span className="font-medium">{(metrics.workerUtilization * 100).toFixed(1)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div 
                  className="bg-blue-500 h-3 rounded-full transition-all duration-500"
                  style={{ width: `${metrics.workerUtilization * 100}%` }}
                ></div>
              </div>
            </div>
            
            <div className="pt-4 border-t">
              <div className="text-sm text-gray-600 space-y-1">
                <div>Avg Task Duration: {metrics.averageTaskDuration} min</div>
                <div>Tasks Completed Today: {metrics.tasksCompletedToday}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};